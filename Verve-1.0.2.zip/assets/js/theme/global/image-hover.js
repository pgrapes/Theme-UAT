import $ from 'jquery';

import utils from '@bigcommerce/stencil-utils';
import ProductDetails from '../common/product-details';

export default function(context) {
   //if($(".verve-prod").length < 1) {
	$('.hover-img').each(function() {
	
    const $hoverImg = $(this);

   const productId = $(this).data('product-id');

	utils.api.product.getById(productId, {template: 'products/hover-image'}, function done(err, response) {
		
           $hoverImg.html(response);
		   
            //return new ProductDetails($hoverImg, context);
			
        });
	   
	});
	//}
}


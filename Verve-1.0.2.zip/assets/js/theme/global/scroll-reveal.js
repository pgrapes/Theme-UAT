import $ from 'jquery';
import ScrollReveal from 'scrollreveal';

export default function() {

	window.sr = ScrollReveal();
    if (sr.isSupported()) {
           document.documentElement.classList.add('sr');
         }
	sr.reveal('.herCarousel .info-block', { origin: 'bottom', distance: '100px' });
	sr.reveal('.vr-home.top-block', { origin: 'top', distance: '100px' });
	sr.reveal('.vr-featured .productCarousel-slide', 200);
	sr.reveal('.vr-new-products .productCarousel-slide', 200);
	sr.reveal('.verve-sub .productCarousel-slide', 200);
	 if($("#search-results-content").length > 0) {
	sr.reveal('.productGrid .product', 100);
	
} else {
	sr.reveal('.productGrid .product', 200);
	
}
sr.reveal('.brands .slide', 160);
}
import $ from 'jquery';

export default function() {
	// store the image link inside a variable from 'src' attribute
	var getImageSrc = $('img#vr-header').attr('src');
    if(getImageSrc) {
	// add div background image using the variable above
	$('.header-img-holder').css('background-image', 'url(' + getImageSrc + ')');
	//$('img#vr-header').addClass('vr-hidden');
}
/*
$('p').each(function(index, item) {
    if($.trim($(item).text()) === "") {
        $(item).remove(); // $(item).remove();
    }
});*/
}



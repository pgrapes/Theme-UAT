import PageManager from '../page-manager';

export default class Home extends PageManager {
}

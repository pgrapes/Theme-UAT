import $ from 'jquery';

export default function () {
    $(window).on('load resize scroll', () => {
        const scrollTop = $(document).scrollTop();
        if (scrollTop > 10) {
            $('.header').addClass('gg-sticky');
        } else {
            $('.header').removeClass('gg-sticky');
        }
    });
}

import Instafeed from '../common/instafeed.min.js';
import $ from 'jquery';
import 'slick-carousel/slick/slick';

export default function () {
    const $carouselInstagram = $('#js-carousel-instagram');
    const $carouselInstagramSidebar = $('#instagram-list__sidebar');
    if ($carouselInstagram.length) {
        var feed = new Instafeed({
            get: 'user',
            target: 'js-carousel-instagram',
            accessToken: '1212301594.1677ed0.4d1a7e036d9945bd9a964afdc8136141',
            userId: 1212301594,
            limit: 12,
            resolution: 'low_resolution',
            resolution2: 'standard_resolution',
            template: '<li class="instagram__item animated"><a  class="instagram__link" href="{{link}}"><img  class="instagram__img" src="{{image}}" /></a></li>',
            after() {
                $carouselInstagram.slick({
                    prevArrow: '<div class="instagram__carousel instagram__carousel--left"><i class="fa fa-angle-left"></i></div>',
                    nextArrow: '<div class="instagram__carousel instagram__carousel--right"><i class="fa fa-angle-right"></i></div>',
                    dots: false,
                    infinite: true,
                    mobileFirst: true,
                    slidesToShow: 2,
                    slidesToScroll: 1,
                    responsive: [
                        {
                            breakpoint: 1260,
                            settings: {
                                slidesToScroll: 1,
                                slidesToShow: 4,
                            },
                        },
                        {
                            breakpoint: 800,
                            settings: {
                                slidesToScroll: 1,
                                slidesToShow: 3,
                            },
                        },
                        {
                            breakpoint: 550,
                            settings: {
                                slidesToScroll: 1,
                                slidesToShow: 1,
                            },
                        },
                    ],
                });
            },
        });
        feed.run();
    }

    if ($carouselInstagramSidebar.length) {
        var feed = new Instafeed({
            get: 'user',
            target: 'instagram-list__sidebar',
            accessToken: '1212301594.1677ed0.4d1a7e036d9945bd9a964afdc8136141',
            userId: 1212301594,
            limit: 12,
            resolution: 'thumbnail',
            resolution2: 'standard_resolution',
        });
        feed.run();
    }
}

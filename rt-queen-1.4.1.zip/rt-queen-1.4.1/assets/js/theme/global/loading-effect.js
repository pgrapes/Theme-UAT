import $ from 'jquery';

const PLUGIN_KEY = 'loadingeffect';


class LoadingEffect {
    constructor() {
        const $this = this;
        $this.handleEffect();
    }
    exists(target) {
        return target.length > 0 ? !0 : !1;
    }
    inView(target) {
        let e = $(window),
            obj = target;
        let a = e.scrollTop(),
            o = e.scrollTop() + obj.height(),
            t = obj.offset().top + 20;
        return o >= t && t >= a ? !0 : !1;
    }
    handleEffect() {
        const $this = this;
        const e = $('.animated:not(.shown)');
        $this.exists(e) && (setTimeout(() => {
            $this.loadingEffect();
        }, 100),
		$(window).on('scroll', () => {
    $this.loadingEffect();
}));
    }
    loadingEffect() {
        const $this = this;
        const e = $('.animated:not(.shown)');
        $this.exists(e) && $this.precessEffect(e);
    }
    precessEffect(e) {
        let a = 0;
        const $this = this;
        e.each(function () {
            const e = $(this);
            $('html.touch').length > 0 ? e.hasClass('shown') || e.hasClass('animation-triggered') || (e.addClass('animation-triggered'), setTimeout(() => {
                e.hasClass('animation-triggered') && e.removeClass('animation-triggered').addClass('shown');
            }, 200)) : e.hasClass('shown') || e.hasClass('animation-triggered') || !$this.inView(e) || (e.addClass('animation-triggered'), a++, setTimeout(() => {
                e.hasClass('animation-triggered') && e.removeClass('animation-triggered').addClass('shown');
            }, 100 * a));
        });
    }
}

export default function () {
    const loading = new LoadingEffect();

    return loading;
}

var data={
	"hero":{
		"title":"THIS IS VIDEO HEADER",
		"description":"Is Optional And Customizable",
		"buttonText":"Purchase Now",
		"buttonLink":"#"
	}
}
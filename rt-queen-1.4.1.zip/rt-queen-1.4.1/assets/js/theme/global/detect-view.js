import $ from 'jquery';

const PLUGIN_KEY = 'DETECTVIEW';

class detect {
    constructor() {
        this.isMobile() ? (this.touch = !0, $('body').addClass('touch'), this.clickEv = 'touchstart') : ($('body').addClass('notouch'), navigator.appVersion.indexOf('Mac') != -1 && navigator.userAgent.indexOf('Safari') > -1 && $('body').addClass('macos'));
    }
    isMobile() {
        const e = navigator.userAgent.toLowerCase();
        return Modernizr.touch || e.match(/(iphone|ipod|ipad)/) || e.match(/(android)/) || e.match(/(iemobile)/) || e.match(/iphone/i) || e.match(/ipad/i) || e.match(/ipod/i) || e.match(/blackberry/i) || e.match(/bada/i) || e.match(/windows phone/i) || e.match(/webOS/i) ? !0 : !1;
    }
}

export default function () {
    const loading = new detect();

    return detect;
}

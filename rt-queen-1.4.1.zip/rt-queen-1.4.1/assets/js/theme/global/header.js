import $ from 'jquery';
const PLUGIN_KEY = 'header';
/*
 * Manage the behaviour of a menu
 * @param {jQuery} $header
 */
class Header {
    constructor($header) {
        const $this = this;
        $this.$header = $header;
        $this.$body = $('body');
        $this.headerTop = $('#header').offset().top,
		$this.touch = !1,
		$this.header_sticky = 'style_3';
        $this.header_sticky = true;

        $this.addHome();
		// Init scroll
        $this.handleMenuScroll();
        $(window).resize(() => {
            $this.handleResetMenuScroll();
        }),
		$(window).scroll(function () {
			const e = $(this).scrollTop();
			$this.handleMenuScroll(e);
		});
		console.log('2222');

		$.getJSON( "./data.setting.json", function( data ) {
		var items = [];
		$.each( data, function( key, val ) {
			items.push( "<li id='" + key + "'>" + val + "</li>" );
		});
		
		$( "<ul/>", {
			"class": "my-new-list",
			html: items.join( "" )
		}).appendTo( "body" );
		});
    }
    handleMenuScroll(e) {
        if (this.header_sticky) {
            const a = $('#header').outerHeight();
            this.touch == 0 && this.getWidthBrowser() >= 1024 && (e > a ? $('#header').hasClass('on') || ($('body').hasClass('templateIndex') || $(`<div style="min-height:${a}px"></div>`).insertBefore('#header'),
			this.header_style == 'style_3' || this.header_style == 'style_4' ? $('#header').addClass('on').addClass('fadeInDown') : $('#header').addClass('on')) : $('#header').hasClass('on') && ($('body').hasClass('templateIndex') || $('#header').prev().remove(), this.header_style == 'style_3' || this.header_style == 'style_4' ? $('#header').removeClass('on').removeClass('fadeInDown') : $('#header').removeClass('on')));
        }
    }
    handleResetMenuScroll() {
        if (this.header_sticky && this.touch == 0) {
            if (this.getWidthBrowser() < 1024) $('#header').hasClass('on') && ($('body').hasClass('templateIndex') || $('#header').prev().remove(), this.header_style == 'style_3' || this.header_style == 'style_4' ? $('#header').removeClass('on').removeClass('fadeInDown') : $('#header').removeClass('on'));
            else {
                let e = $(this).scrollTop(),
                    a = $('#header').outerHeight();
                e > a && ($('#header').hasClass('on') || ($('body').hasClass('templateIndex') || $(`<div style="min-height:${a}px"></div>`).insertBefore('#header'), this.header_style == 'style_3' || this.header_style == 'style_4' ? $('#header').addClass('on').addClass('fadeInDown') : $('#header').addClass('on')));
            }
        }
    }
    getWidthBrowser() {
        let e;
        return typeof window.innerWidth === 'number' ? e = window.innerWidth : document.documentElement && (document.documentElement.clientWidth || document.documentElement.clientHeight) ? e = document.documentElement.clientWidth : document.body && (document.body.clientWidth || document.body.clientHeight) && (e = document.body.clientWidth), e;
    }
    getHeightBrowser() {
        let e;
        return typeof window.innerHeight === 'number' ? e = window.innerHeight : document.documentElement && (document.documentElement.clientWidth || document.documentElement.clientHeight) ? e = document.documentElement.clientHeight : document.body && (document.body.clientWidth || document.body.clientHeight) && (e = document.body.clientHeight), e;
    }
    addHome() {
        if ($('.js-home-page').length) {
            $('#header').addClass('header--home');
        }
    }
}

export default function () {
    const $header = $('#header').eq(0);

    const header = new Header($header);

    return header;
}

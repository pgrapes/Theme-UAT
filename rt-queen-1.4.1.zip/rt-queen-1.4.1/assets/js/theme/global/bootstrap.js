import $ from 'jquery';
import bootstrap from './bootstrap/bootstrap.min';
export default function () {

	const $tooltip = $('[data-toggle="tooltip"]');
    if($tooltip.length){
        $tooltip.tooltip();
    }

    const $dropdown = $('[data-toggle="dropdown"]');
	if($dropdown.length){
        $dropdown.dropdown();
    }

    const $collapse = $('[data-toggle="collapse"]');
    if($collapse.length){
        $collapse.collapse();
    }
}
import $ from 'jquery';
import 'slick-carousel/slick/slick';

export default function () {
    const $carousel = $('[data-slick]');
    const $option = $carousel.data('slick');
    if ($carousel.length) {
        $carousel.slick({
            prevArrow:'<div class="slick-prev"><span class="btn medium"><i class="fa fa-angle-left"></i></span></div>',
            nextArrow:'<div class="slick-next"><span class="btn medium"><i class="fa fa-angle-right"></i></span></div>',
            $option
        });
    }
}

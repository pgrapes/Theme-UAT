import $ from 'jquery';
import 'history.js/scripts/bundled-uncompressed/html4+html5/jquery.history';
import PageManager from '../page-manager';
import quickSearch from './global/quick-search';
import currencySelector from './global/currency-selector';
import foundation from './global/foundation';
import quickView from './global/quick-view';
import cartPreview from './global/cart-preview';
//import compareProducts from './global/compare-products';
import privacyCookieNotification from './global/cookieNotification';
import maintenanceMode from './global/maintenanceMode';
import bannerSubtext from './global/banner-subtext';
import carousel from './common/carousel';
import subHeadings from './common/subheadings';
import loadingProgressBar from './global/loading-progress-bar';
import {revealClose, revealReset} from './global/reveal-extension';
import FastClick from 'fastclick';
import headerImage from './common/header-image';
import matchHeight from './common/match-height';
import imgHover from './global/image-hover';
import quickRemove from './global/quick-remove';
import closeCart from './global/close-cart';
import mainMenu from './global/menu';
import ScrollReveal from './global/scroll-reveal';

function fastClick(element) {
    return new FastClick(element);
}

export default class Global extends PageManager {
    constructor() {
        super();
    }

    /**
     * You can wrap the execution in this method with an asynchronous function map using the async library
     * if your global modules need async callback handling.
     * @param next
     */
    loaded(next) {
        fastClick(document.body);
        quickSearch();
        currencySelector();
        foundation($(document));
        quickView(this.context);
        cartPreview();
        //compareProducts();
        carousel();
		subHeadings();
        mainMenu();
		bannerSubtext();
        privacyCookieNotification();
        maintenanceMode(this.context.maintenanceMode);
        loadingProgressBar();
        revealClose();
        revealReset();
		headerImage();
		matchHeight();
		imgHover(this.context);
		quickRemove();
		closeCart();
		ScrollReveal();
        next();
    }
}